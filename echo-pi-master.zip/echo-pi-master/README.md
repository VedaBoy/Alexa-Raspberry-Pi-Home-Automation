# echo-pi
Controlling Raspberry Pi GPIO with Amazon Echo using fauxmo
This is to overcome the limitation of changing URL's for tunnel while using ngrok.

For detailed instructions refer to the [instructable](https://www.instructables.com/id/Control-Raspberry-Pi-GPIO-Using-Amazon-Echo-Fauxmo/)
